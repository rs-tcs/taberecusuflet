
<div id="dialog_update_plugin" class="api_wrapper" title="<?php _e("Update Slider Plugin",REVSLIDER_TEXTDOMAIN)?>" style="display:none;">
		<div class="api-caption"><?php _e("Update Revolution Slider Plugin",REVSLIDER_TEXTDOMAIN)?>:</div>
		<div class="api-desc">
			<?php _e("To update the slider please show the slider install package. The files will be overwriten.",REVSLIDER_TEXTDOMAIN) ?>
			<br> <?php _e("File example: revslider.zip")?>
		</div>
		
		<br>
		
		<form action="<?php echo UniteBaseClassRev::$url_ajax?>" enctype="multipart/form-data" method="post">
		    
		    <input type="hidden" name="action" value="revslider_ajax_action">
		    <input type="hidden" name="client_action" value="update_plugin">
		    
		    <?php _e("Choose the update file:",REVSLIDER_TEXTDOMAIN)?>   
		    <br>
			<input type="file" name="update_file" class="input_update_slider">
			
			<input type="submit" class='button-secondary' value="<?php _e("Update Slider",REVSLIDER_TEXTDOMAIN)?>">
		</form>
				
</div>

